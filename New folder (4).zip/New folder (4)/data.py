import json
import platform

print(platform.machine())
print(platform.platform())
print(platform.processor())
print(platform.uname())



# example dictionary that contains data like you want to have in json
# dic={'platform': platform.platform(), 'name': 'mkyong.com', 'messages': ['msg 1', 'msg 2', 'msg 3']}
dic = {'platform':platform.platform(),'attributes':[{'machine':platform.machine(),'processor':platform.processor()}]}
# get json string from that dictionary
json=json.dumps(dic)
print(json)
f=open('myfile','w')
print(json,file=f)
f.close()