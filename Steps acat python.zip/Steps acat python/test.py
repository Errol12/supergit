import platform
print("Hello, Python!")
print(platform.machine())
print(platform.platform())
print(platform.processor())
print(platform.uname())
input('Press ENTER to exit')
